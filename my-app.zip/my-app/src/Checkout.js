import React from "react";
class Checkout extends React.Component {
    state = { name: "", email: "", file: null };
    fileRef = null;
    saveData(e) {
    e.preventDefault();
    console.log("form submission logic here", this.state, this.fileRef.files);
    }
    render() {
    return (
    <form onSubmit={(ev) => this.saveData(ev)}>
    <div>
    <label>Name</label>
    {/* CONTROLLED */}
    <input
    type="text"
    onChange={(e) => this.setState({ name: e.target.value })}
    />
    {this.state.name === "" ? <small>Name is required</small> : null}
    </div>
    <div>
    <label>Email</label>
    {/* UNCONTROLLED */}
    <input
    type="text"
    onChange={(e) => this.setState({ email: e.target.value })}
    />
    {this.state.email === "" ? <small>Name is required</small> : null}
    {/* {this.emailRef && this.emailRef.value === "" ? (
    <small>Email is required</small>
    ) : null} */}
    </div>
    <input type="file" ref={(r) => (this.fileRef = r)} />
    <button type="submit">Submit</button>
    </form>
    );
    }
    }

    export default Checkout;