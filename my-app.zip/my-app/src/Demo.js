import React from "react";
class Demo extends React.PureComponent{
    //every component must have a render method
    state = {Location: "A" ,count:1};
    render(){
        console.log("Render Called",this.state);
        //every render must return something always
        const name="Keerthana"
        return(
            <div>
            <h1>Demo Component</h1>
            <p>{3+4}</p>
            <p>{this.state.count>5?name.toUpperCase(): null}</p>
            <p>{name.toUpperCase()}</p>
            <button onClick={()=>this.setState({count:this.state.count+1})}>increment</button>
            <button onClick={()=>this.setState({location: "A"})}>A</button>
            <button onClick={()=>this.setState({location:"B"})}>B</button>
            </div>
        );
    }
}

export default Demo;