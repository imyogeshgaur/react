import React from 'react';

class Demo extends React.Component {
    // every component must have a render
    render() {
        // every render must return something always
        let name = "Yogesh Gaur"
        return (
            <div>
                <h1>Demo Component</h1>
                <p>{name}</p>
            </div>
        )
    }
}

export default Demo;