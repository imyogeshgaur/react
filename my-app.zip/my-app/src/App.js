import './App.css';
// import Demo from './Demo';
import { ThemeContext } from './context';


import ProductList from './containers/ProductList';
import Demo from './Demo';
import Checkout from './Checkout';
import ThemeSwitch from './components/ThemeSwitch';
import React from 'react';

function App() {
  let [theme,setTheme] = React.useState("light");
  return (
    <div className='App'>
      <ThemeSwitch changeTheme={(thm)=>setTheme(thm)}/>
      <ThemeContext.Provider value={theme}>
      <ProductList/>
      </ThemeContext.Provider>
    </div>
  );
}

export default App;
