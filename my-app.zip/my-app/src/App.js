import { useState } from 'react';
import './App.css';
import Checkout from './Components/Checkout';
import Product from './Components/Product';
import ThemeSwitch from './Components/ThemeSwitch';
import ProductList from './Containers/ProductList';
import { ThemeContext } from './Context';
import Demo from './Demo';
import DemoNext from './DemoNext';

function App() {
  const [theme, setTheme] = useState("light")
  return (
    <div className="App">
      {/* <Demo />
     <Product /> */}
      <ThemeSwitch changeTheme={() => setTheme(theme)} />
      <ThemeContext value={theme}>
        <ProductList />
      </ThemeContext>
      {/* <DemoNext /> */}
      {/* <Checkout /> */}
    </div>
  );
}

export default App;
