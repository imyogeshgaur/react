import React, { Component } from 'react'
import Product from '../components/Product';
import {getProducts} from '../services/ProductService'
//LOGICAL COMPONENT
class ProductList extends Component {
   state = {plist:[]}
    componentDidMount(){
        this.getData()
    }
    async getData(){
        try{
            const response = await getProducts();
            // console.log(response);
            // this.state.plist= response.data;//mutating state
            this.setState({plist:response.data})

        }catch(e){
            console.log(e);
        }
    }
  render() {
    // const plist =[ {
    //     productId: 100,
    //     productName: "test",
    //     productPrice: 2000,
    //     productImage: "/watch.png",
    //     productStock:20,
    // },
    // {
    //     productId: 101,
    //     productName: "test",
    //     productPrice: 2000,
    //     productImage: "/watch.png",
    //     productStock:0,
    // }];
    return (
      <div className='row'>
        
        {
            this.state.plist.map((item)=><Product key={item.productId} pdata={item}
                btnClick={(id)=>console.log("add item",id)}/>
            )
        }
      </div>
    );
  }
}
export default ProductList;
