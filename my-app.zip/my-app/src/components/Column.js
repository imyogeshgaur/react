import React from "react";
import { ThemeContext } from "../context";

function Column(props){
    //In function component function itself act as a render method
    const theme = React.useContext(ThemeContext);
    const color = theme === "light"?"text-dark":"text-white";
    const cls = `col-md-${props.size} ${color}`;
    return <div className={cls}>{props.children}</div>
}

export default Column;