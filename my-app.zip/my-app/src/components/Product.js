import React from "react";
import Column from "./Column";
//PRESENTATIONAL COMPONENT
class Product extends React.Component{
    renderStock(){
        if(this.props.pdata.productStock){
            return <button >Add to cart</button>
        }return <p>Out of Stock</p>
    }
    render(){
        const data = this.props.pdata;
       
        return(
              <Column size={4}>
                <img height="400"  src={data.productImage} />
                <h4>{data.productName}</h4>
                <h5>{data.productPrice}</h5>
                {this.renderStock()}
                {data.productStock > 10 ? (
                <button onClick={()=>this.props.btnClick(data.productId)}>Add to Cart</button>
                ):null}
                </Column>
                );
        
    }
}

export default Product; 