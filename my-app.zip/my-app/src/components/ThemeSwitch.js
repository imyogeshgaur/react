import React from "react";
function ThemeSwitch(props) {
    //const [state_variable,alternative_setState]=React.useState(initialState);
    let [theme,setTheme]=React.useState("light");
    let[count,setCount]=React.useState(0);

    React.useEffect(()=>{
        console.log("Side Effect is called");
        document.body.className="bg-"+theme;
    },[
        //didMount : empty array
        theme,
    ])
if (theme === "light") {
    return <button onClick={()=>{
        setTheme("dark");
        props.changeTheme('dark');
    }}>Dark</button>
}
return <button className="btn btn-danger" onClick={() => {setTheme("light")
        props.changeTheme('light')}}>Light</button>;
}

export default ThemeSwitch;