import React, { useContext } from 'react'
import { ThemeContext } from '../Context'

const Columns = (props) => {
  const theme = useContext(ThemeContext)
  const color = theme ==="light"?"text-dark":"text-white"
  const cls = `col-md-${props.size} ${color}`
    return (
    <div className={cls}>{props.children}</div>
  )
}

export default Columns