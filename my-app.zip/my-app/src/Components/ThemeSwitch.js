import React, { useEffect, useState } from 'react'

const ThemeSwitch = (props) => {
    const [theme, setTheme] = useState("light")
    useEffect(() => {
      document.body.className = `bg-${theme}`
    },[
        theme
        // didMount:Empty Array
    ])
    
    if (theme === "light") {
        return <button onClick={() => {
            setTheme("dark")
            props.changeTheme('dark')
        }}>Dark</button>;
    }
    return <button onClick={() => {
        setTheme("light")
        props.changeTheme('light')
    }}>Light</button>;
}

export default ThemeSwitch