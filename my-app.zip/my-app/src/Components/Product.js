import React, { Component } from 'react'
import Columns from './Columns';

export default class Product extends Component {
    render() {
    const data = this.props.pdata;
        return (
            <Columns size={4}>
                <img src={data.productImage} />
                <h4>{data.productName}</h4>
                <h5>{data.productPrice}</h5>
                {
                    data.productStock > 0 ?(
                        <button onClick={()=>this.props.btnClick(data.productId)}>Add to Cart</button>
                    ):null
                }
            </Columns>
        );
    }
}
