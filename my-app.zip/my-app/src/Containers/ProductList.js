import React from "react";
import Product from "../Components/Product";
import { getProducts } from "../services/ProductService";


class ProductList extends React.Component {
    state = { plist: [] }
    componentDidMount() {
        this.getData()
    }
    async getData() {
        try {
            const data = await getProducts();
            this.state.plist = data;
            this.setState(this.state);
        } catch (e) {
            console.log(e);
        }
    }
    render() {
        return (
            <div className="row">
                {
                    this.state.plist.map((item) => (
                        <Product key={item.productId} pdata={item} btnClick={(id) => console.log("Add Item", id)} />
                    ))
                }
            </div>
        );
    }
}
export default ProductList;