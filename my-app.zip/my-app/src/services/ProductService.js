import Axios from 'axios'

export const getProducts=()=>{
    const url = "/Data.json";
    return Axios.get(url);
};

