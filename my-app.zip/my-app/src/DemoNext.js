import React, { Component } from 'react'

export default class DemoNext extends Component {
  state = {location:"A",count:0}
  //To check Wether the render occur or not 
  shouldComponentUpdate(nextProp,nextState){
    return this.state.location != nextState.location || this.state.count > 4
  }
    render() {
        console.log("Render Called !!!",this.state)
        name = "yogesh"
    return (
      <>
        <h1>Demo Component</h1>
        <p>{this.state.count > 5 ? name.toUpperCase():null}</p>
        <button onClick={()=>this.setState({count:this.state.count + 1})}>Increment</button>
        <button onClick={()=>this.setState({location:'A'})}>A</button>
        <button onClick={()=>this.setState({location:'B'})}>B</button>
      </>
    )
  }
}
